import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";

const FormSchema = z.object({
  qtd: z.number().min(1),
});

export function Inputs() {
  const form = useForm<z.infer<typeof FormSchema>>({
    resolver: zodResolver(FormSchema),
    defaultValues: {
      qtd: 0,
    },
  });

  function onSubmit(path: string) {
    return (data: z.infer<typeof FormSchema>) => {
      console.log(data);
    };
  }
  return (
    <>
      <Form {...form}>
        <form className="flex">
          <FormField
            control={form.control}
            name="qtd"
            render={({ field }) => (
              <FormItem>
                <FormControl>
                  <Input
                    {...field}
                    value={field.value ?? ""}
                    onChange={(e) =>
                      field.onChange(
                        e.target.value === "" ? null : Number(e.target.value)
                      )
                    }
                    className="w-14"
                  />
                </FormControl>
              </FormItem>
            )}
          />
          <Button className="pl-0 pr-0 w-full">Parc.</Button>
          <Button
            onClick={form.handleSubmit(onSubmit("/conferir"))}
            className="pl-0 pr-0 w-full"
          >
            Comp.
          </Button>
        </form>
      </Form>
    </>
  );
}
